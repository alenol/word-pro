# -*- coding: utf-8 -*-
"""PDF 编辑器窗口。

功能：
- 打开 PDF 并以页面图像形式显示（PyMuPDF 渲染）
- 支持叠加编辑：添加文本、矩形、直线、高亮标注
- 编辑结果可保存为新的 PDF，或转换为 Word（复用 wfp_pdf_tools）
- 转换后的 Word 可一键导入排版工具

说明：编辑采用"覆盖层"模型——所有标注叠加在原页面上，
保存时通过 PyMuPDF 重新绘制到页面后输出新 PDF。
"""

from __future__ import annotations

import os

try:
    import fitz  # PyMuPDF
    FPDF_AVAILABLE = True
except Exception:  # pragma: no cover
    fitz = None
    FPDF_AVAILABLE = False

try:
    from PIL import Image, ImageTk
    PIL_AVAILABLE = True
except Exception:  # pragma: no cover
    PIL_AVAILABLE = False

PDF_TOOLS_IMPORT_ERROR = None
try:
    from wfp_pdf_tools import pdf_to_docx
except Exception as e:  # pragma: no cover
    pdf_to_docx = None
    PDF_TOOLS_IMPORT_ERROR = e


# 工具常量
TOOL_TEXT = "text"
TOOL_RECT = "rect"
TOOL_LINE = "line"
TOOL_HIGHLIGHT = "highlight"

TOOL_LABELS = {
    TOOL_TEXT: "文本",
    TOOL_RECT: "矩形",
    TOOL_LINE: "直线",
    TOOL_HIGHLIGHT: "高亮",
}


class PDFEditorWindow:
    """PDF 编辑器窗口。"""

    def __init__(self, master, file_path=None, log=None):
        self.master = master
        self.log = log or (lambda msg: None)
        self.doc = None
        self.file_path = None
        self.current_page = 0
        self.page_count = 0
        self.scale = 1.2          # 显示缩放
        self.zoom = 1.2
        self.annots = {}          # page_index -> list[annot dict]
        self.tool = TOOL_TEXT
        self.text_color = "#000000"
        self.draw_color = "#ff0000"
        self.hl_color = "#ffff00"
        self.stroke_width = 2
        self.font_size = 12

        # 交互状态
        self._drag_start = None
        self._tk_image = None

        if not FPDF_AVAILABLE:
            from tkinter import messagebox
            messagebox.showerror("缺少依赖", "PDF 编辑功能需要 PyMuPDF (pymupdf)，请先安装：\npip install pymupdf")
            return

        self._build_ui()
        if file_path:
            self.open_pdf(file_path)

    # ------------------------------------------------------------------
    def _build_ui(self):
        import tkinter as tk
        from tkinter import ttk

        self.win = tk.Toplevel(self.master)
        self.win.title("PDF 编辑器")
        self.win.geometry("980x760")
        self.win.transient(self.master)

        # 顶部工具栏
        toolbar = ttk.Frame(self.win)
        toolbar.pack(side=tk.TOP, fill=tk.X, padx=6, pady=4)

        ttk.Button(toolbar, text="打开 PDF", command=self._ask_open).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="上一页", command=self.prev_page).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="下一页", command=self.next_page).pack(side=tk.LEFT, padx=2)
        self.page_label = ttk.Label(toolbar, text="0 / 0")
        self.page_label.pack(side=tk.LEFT, padx=6)

        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=6)

        # 工具选择
        self.tool_var = tk.StringVar(value=TOOL_TEXT)
        for tool_id, label in TOOL_LABELS.items():
            ttk.Radiobutton(
                toolbar, text=label, value=tool_id, variable=self.tool_var,
                command=lambda: setattr(self, "tool", self.tool_var.get())
            ).pack(side=tk.LEFT, padx=2)

        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=6)

        ttk.Label(toolbar, text="字号:").pack(side=tk.LEFT)
        self.size_var = tk.StringVar(value="12")
        size_spin = ttk.Spinbox(toolbar, from_=6, to=72, width=4, textvariable=self.size_var)
        size_spin.pack(side=tk.LEFT, padx=2)

        ttk.Label(toolbar, text="颜色:").pack(side=tk.LEFT)
        self.color_var = tk.StringVar(value="#ff0000")
        ttk.Entry(toolbar, textvariable=self.color_var, width=9).pack(side=tk.LEFT, padx=2)

        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=6)

        ttk.Button(toolbar, text="撤销", command=self.undo).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="清空本页标注", command=self.clear_page).pack(side=tk.LEFT, padx=2)

        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=6)

        ttk.Button(toolbar, text="转 Word", command=self.export_to_word).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="另存为 PDF", command=self.save_as_pdf).pack(side=tk.LEFT, padx=2)

        # 画布
        canvas_frame = ttk.Frame(self.win)
        canvas_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=6, pady=4)
        self.canvas = tk.Canvas(canvas_frame, background="#808080", highlightthickness=0)
        hbar = ttk.Scrollbar(canvas_frame, orient=tk.HORIZONTAL, command=self.canvas.xview)
        vbar = ttk.Scrollbar(canvas_frame, orient=tk.VERTICAL, command=self.canvas.yview)
        self.canvas.configure(xscrollcommand=hbar.set, yscrollcommand=vbar.set)
        hbar.pack(side=tk.BOTTOM, fill=tk.X)
        vbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.canvas.bind("<ButtonPress-1>", self._on_press)
        self.canvas.bind("<B1-Motion>", self._on_drag)
        self.canvas.bind("<ButtonRelease-1>", self._on_release)
        self.canvas.bind("<MouseWheel>", self._on_wheel)

        # 底部状态栏
        status = ttk.Label(self.win, text="选择工具后在页面上点击/拖拽添加标注", anchor="w")
        status.pack(side=tk.BOTTOM, fill=tk.X, padx=6, pady=2)

    # ------------------------------------------------------------------
    # PDF 打开与渲染
    # ------------------------------------------------------------------
    def open_pdf(self, file_path):
        if not os.path.exists(file_path):
            self.log(f"[PDF编辑] 文件不存在: {file_path}")
            return
        try:
            if self.doc is not None:
                self.doc.close()
            self.doc = fitz.open(file_path)
            self.file_path = file_path
            self.page_count = len(self.doc)
            self.current_page = 0
            if self.page_count == 0:
                from tkinter import messagebox
                messagebox.showwarning("提示", "PDF 中没有页面。", parent=self.win)
                return
            self._render_page()
            self.log(f"[PDF编辑] 已打开: {os.path.basename(file_path)}（{self.page_count} 页）")
        except Exception as e:
            from tkinter import messagebox
            messagebox.showerror("打开失败", f"无法打开 PDF：\n{e}", parent=self.win)

    def _ask_open(self):
        from tkinter import filedialog
        path = filedialog.askopenfilename(
            title="选择 PDF 文件", filetypes=[("PDF 文件", "*.pdf"), ("所有文件", "*.*")]
        )
        if path:
            self.open_pdf(path)

    def _get_page_pixmap(self, page_index):
        page = self.doc[page_index]
        mat = fitz.Matrix(self.zoom, self.zoom)
        pix = page.get_pixmap(matrix=mat, alpha=False)
        return pix

    def _render_page(self):
        if self.doc is None or self.page_count == 0:
            return
        self.canvas.delete("all")
        page = self.doc[self.current_page]
        rect = page.rect
        pix = self._get_page_pixmap(self.current_page)

        if PIL_AVAILABLE:
            pil_img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
            self._tk_image = ImageTk.PhotoImage(pil_img)
        else:  # pragma: no cover
            png_path = os.path.join(os.environ.get("TEMP", "/tmp"), f"_wfp_pdf_{id(self)}.png")
            pix.save(png_path)
            self._tk_image = self.canvas.create_image(png_path)
            self._png_path = png_path
            self.canvas.create_image(0, 0, anchor="nw", image=self._tk_image)
            return

        self.canvas.create_image(0, 0, anchor="nw", image=self._tk_image)
        # 记录画布坐标与 PDF 坐标换算基准
        self._pdf_rect = rect
        self._zoom = self.zoom
        self.canvas.configure(scrollregion=(0, 0, pix.width, pix.height))

        # 重绘已有标注（PDF 坐标 -> 画布坐标）
        for annot in self.annots.get(self.current_page, []):
            self._draw_annot_canvas(annot)

        self.page_label.config(text=f"{self.current_page + 1} / {self.page_count}")

    def _pdf_to_canvas(self, x, y):
        return x * self.zoom, y * self.zoom

    def _canvas_to_pdf(self, cx, cy):
        return cx / self.zoom, cy / self.zoom

    # ------------------------------------------------------------------
    # 标注模型（PDF 坐标，points）
    # ------------------------------------------------------------------
    def _add_annot(self, annot):
        self.annots.setdefault(self.current_page, []).append(annot)
        self._draw_annot_canvas(annot)

    def _draw_annot_canvas(self, annot):
        a_type = annot["type"]
        if a_type == TOOL_TEXT:
            x, y = self._pdf_to_canvas(annot["x"], annot["y"])
            self.canvas.create_text(
                x, y, text=annot["text"], anchor="nw",
                fill=annot.get("color", "#000000"),
                font=("SimHei", max(6, int(annot.get("size", 12) * self.zoom)))
            )
        elif a_type == TOOL_RECT:
            x0, y0 = self._pdf_to_canvas(annot["x0"], annot["y0"])
            x1, y1 = self._pdf_to_canvas(annot["x1"], annot["y1"])
            self.canvas.create_rectangle(
                x0, y0, x1, y1, outline=annot.get("color", "#ff0000"),
                width=annot.get("width", 2)
            )
        elif a_type == TOOL_LINE:
            x0, y0 = self._pdf_to_canvas(annot["x0"], annot["y0"])
            x1, y1 = self._pdf_to_canvas(annot["x1"], annot["y1"])
            self.canvas.create_line(
                x0, y0, x1, y1, fill=annot.get("color", "#ff0000"),
                width=annot.get("width", 2)
            )
        elif a_type == TOOL_HIGHLIGHT:
            x0, y0 = self._pdf_to_canvas(annot["x0"], annot["y0"])
            x1, y1 = self._pdf_to_canvas(annot["x1"], annot["y1"])
            self.canvas.create_rectangle(
                x0, y0, x1, y1, outline="", fill=annot.get("color", "#ffff00"),
                stipple="gray50"
            )

    # ------------------------------------------------------------------
    # 交互
    # ------------------------------------------------------------------
    def _on_press(self, event):
        if self.doc is None:
            return
        if self.tool == TOOL_TEXT:
            self._prompt_add_text(event)
            return
        self._drag_start = (event.x, event.y)
        # 预览形状
        self._preview_id = None

    def _on_drag(self, event):
        if self._drag_start is None or self.tool == TOOL_TEXT:
            return
        if getattr(self, "_preview_id", None):
            self.canvas.delete(self._preview_id)
        x0, y0 = self._drag_start
        self._preview_id = self.canvas.create_rectangle(
            x0, y0, event.x, event.y,
            outline=self.color_var.get(), width=self._stroke_width()
        )

    def _on_release(self, event):
        if self._drag_start is None or self.tool == TOOL_TEXT:
            self._drag_start = None
            return
        if getattr(self, "_preview_id", None):
            self.canvas.delete(self._preview_id)
            self._preview_id = None
        x0, y0 = self._drag_start
        x1, y1 = event.x, event.y
        self._drag_start = None
        p0 = self._canvas_to_pdf(x0, y0)
        p1 = self._canvas_to_pdf(x1, y1)
        color = self.color_var.get()
        width = self._stroke_width()
        if self.tool == TOOL_RECT:
            self._add_annot({"type": TOOL_RECT, "x0": p0[0], "y0": p0[1], "x1": p1[0], "y1": p1[1], "color": color, "width": width})
        elif self.tool == TOOL_LINE:
            self._add_annot({"type": TOOL_LINE, "x0": p0[0], "y0": p0[1], "x1": p1[0], "y1": p1[1], "color": color, "width": width})
        elif self.tool == TOOL_HIGHLIGHT:
            self._add_annot({"type": TOOL_HIGHLIGHT, "x0": min(p0[0], p1[0]), "y0": min(p0[1], p1[1]), "x1": max(p0[0], p1[0]), "y1": max(p0[1], p1[1]), "color": self.hl_color})

    def _stroke_width(self):
        try:
            return max(1, int(float(self.size_var.get()) / 4))
        except (ValueError, TypeError):
            return 2

    def _prompt_add_text(self, event):
        import tkinter as tk
        from tkinter import simpledialog

        x, y = self._canvas_to_pdf(event.x, event.y)
        text = simpledialog.askstring(
            "添加文本", "输入要添加的文本：",
            parent=self.win
        )
        if text:
            try:
                size = float(self.size_var.get())
            except (ValueError, TypeError):
                size = 12
            self._add_annot({
                "type": TOOL_TEXT, "x": x, "y": y,
                "text": text, "color": self.color_var.get(), "size": size
            })

    def _on_wheel(self, event):
        if self.doc is None:
            return
        if event.delta > 0:
            self.current_page = max(0, self.current_page - 1)
        else:
            self.current_page = min(self.page_count - 1, self.current_page + 1)
        self._render_page()

    def next_page(self):
        if self.doc is None:
            return
        if self.current_page < self.page_count - 1:
            self.current_page += 1
            self._render_page()

    def prev_page(self):
        if self.doc is None:
            return
        if self.current_page > 0:
            self.current_page -= 1
            self._render_page()

    def undo(self):
        anns = self.annots.get(self.current_page, [])
        if anns:
            anns.pop()
            self._render_page()

    def clear_page(self):
        self.annots[self.current_page] = []
        self._render_page()

    # ------------------------------------------------------------------
    # 导出
    # ------------------------------------------------------------------
    def _export_pdf_bytes(self, target_path):
        """将标注叠加到原 PDF 并写入 target_path。返回 (ok, error)。"""
        if self.doc is None:
            return False, "尚未打开 PDF"
        try:
            out_doc = fitz.open()
            for page_index in range(self.page_count):
                src = self.doc[page_index]
                new_page = out_doc.new_page(width=src.rect.width, height=src.rect.height)
                new_page.show_pdf_page(new_page.rect, self.doc, page_index)
                for annot in self.annots.get(page_index, []):
                    self._apply_annot_pdf(new_page, annot)
            out_doc.save(target_path, deflate=True, garbage=3)
            out_doc.close()
            return True, None
        except Exception as e:
            return False, str(e)

    def _apply_annot_pdf(self, page, annot):
        a_type = annot["type"]
        color = self._hex_to_rgb(annot.get("color", "#000000"))
        if a_type == TOOL_TEXT:
            try:
                page.insert_text(
                    fitz.Point(annot["x"], annot["y"]),
                    annot["text"],
                    fontsize=annot.get("size", 12),
                    color=color,
                    fontname="china-s",
                )
            except Exception:
                page.insert_text(
                    fitz.Point(annot["x"], annot["y"]),
                    annot["text"],
                    fontsize=annot.get("size", 12),
                    color=color,
                )
        elif a_type == TOOL_RECT:
            page.draw_rect(
                fitz.Rect(annot["x0"], annot["y0"], annot["x1"], annot["y1"]),
                color=color, width=annot.get("width", 2)
            )
        elif a_type == TOOL_LINE:
            page.draw_line(
                fitz.Point(annot["x0"], annot["y0"]),
                fitz.Point(annot["x1"], annot["y1"]),
                color=color, width=annot.get("width", 2)
            )
        elif a_type == TOOL_HIGHLIGHT:
            rect = fitz.Rect(annot["x0"], annot["y0"], annot["x1"], annot["y1"])
            page.draw_rect(rect, color=None, fill=self._hex_to_rgb(annot.get("color", "#ffff00")))
            try:
                page.add_highlight_annot(rect)
            except Exception:
                pass

    @staticmethod
    def _hex_to_rgb(hex_color):
        hex_color = str(hex_color).lstrip("#")
        if len(hex_color) == 3:
            hex_color = "".join(c * 2 for c in hex_color)
        try:
            return tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))
        except ValueError:
            return (0, 0, 0)

    def save_as_pdf(self):
        from tkinter import filedialog, messagebox
        if self.doc is None:
            messagebox.showwarning("提示", "尚未打开 PDF。", parent=self.win)
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".pdf", filetypes=[("PDF 文件", "*.pdf")],
            initialfile=os.path.splitext(os.path.basename(self.file_path or "document"))[0] + "_edited.pdf"
        )
        if not path:
            return
        ok, err = self._export_pdf_bytes(path)
        if ok:
            self.log(f"[PDF编辑] 已保存: {path}")
            messagebox.showinfo("成功", f"PDF 已保存至：\n{path}", parent=self.win)
        else:
            messagebox.showerror("保存失败", f"导出 PDF 失败：\n{err}", parent=self.win)

    def export_to_word(self):
        from tkinter import filedialog, messagebox
        if self.doc is None:
            messagebox.showwarning("提示", "尚未打开 PDF。", parent=self.win)
            return
        if pdf_to_docx is None:
            messagebox.showerror("缺少依赖", f"无法导入 wfp_pdf_tools：\n{PDF_TOOLS_IMPORT_ERROR}", parent=self.win)
            return
        # 先合成带标注的临时 PDF
        import tempfile
        tmp_fd, tmp_pdf = tempfile.mkstemp(suffix=".pdf")
        os.close(tmp_fd)
        ok, err = self._export_pdf_bytes(tmp_pdf)
        if not ok:
            try:
                os.remove(tmp_pdf)
            except OSError:
                pass
            messagebox.showerror("转换失败", f"合成 PDF 失败：\n{err}", parent=self.win)
            return

        base = os.path.splitext(os.path.basename(self.file_path or "document"))[0]
        path = filedialog.asksaveasfilename(
            defaultextension=".docx", filetypes=[("Word 文档", "*.docx")],
            initialfile=base + ".docx"
        )
        if not path:
            try:
                os.remove(tmp_pdf)
            except OSError:
                pass
            return
        try:
            pdf_to_docx(tmp_pdf, path, log=self.log)
            self.log(f"[PDF编辑] 已转 Word: {path}")
            messagebox.showinfo("成功", f"PDF 已转换为 Word：\n{path}\n\n可在主界面添加该文件进行一键排版。", parent=self.win)
        except Exception as e:
            messagebox.showerror("转换失败", f"转换为 Word 失败：\n{e}", parent=self.win)
        finally:
            try:
                os.remove(tmp_pdf)
            except OSError:
                pass

    def close(self):
        if self.doc is not None:
            try:
                self.doc.close()
            except Exception:
                pass
        try:
            self.win.destroy()
        except Exception:
            pass


def open_pdf_editor(master, file_path=None, log=None):
    return PDFEditorWindow(master, file_path=file_path, log=log)
