# -*- coding: utf-8 -*-
"""PDF 工具模块：PDF→Word 转换、PDF 排版参数提取。

本模块独立于 Tkinter，核心逻辑可在 GUI / CLI 中复用。
PDF 文本与图片均通过 PyMuPDF 解析，转换为 .docx 时：
- 文本块按阅读顺序重建为段落（保留基本字号/对齐/加粗信息）；
- 图片块以真实图片形式插入到 Word 中与源 PDF 对应的位置。
"""

from __future__ import annotations

import io
import os
from pathlib import Path

try:  # PyMuPDF >= 1.24 推荐 pymupdf；旧版本用 fitz
    import pymupdf as fitz  # type: ignore
    _FITZ_NAME = "pymupdf"
except Exception:  # pragma: no cover
    import fitz  # type: ignore
    _FITZ_NAME = "fitz"

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Cm, Pt


# 常用中文字号 -> 磅值，用于将 PDF 内字号就近归类，便于排版工具统一
COMMON_SIZE_PTS = [26, 24, 22, 18, 16, 15, 14, 12, 10.5, 9]


def _nearest_common_size(pt_value: float) -> float:
    """将任意磅值就近归并到常用字号。"""
    if not pt_value or pt_value <= 0:
        return 16.0
    best = min(COMMON_SIZE_PTS, key=lambda s: abs(s - pt_value))
    return best


def _points_to_cm(value) -> float:
    try:
        return round(value / 28.3465, 2)
    except (TypeError, ValueError):
        return 0.0


def _extract_block_alignment(block: dict, page_width: float):
    """根据文本块水平位置推断对齐方式（左/中/右/两端）。"""
    x0, y0, x1, y1 = block.get("bbox", (0, 0, 0, 0))
    if page_width <= 0:
        return WD_ALIGN_PARAGRAPH.LEFT
    center = (x0 + x1) / 2.0
    left_gap = x0
    right_gap = page_width - x1
    tolerance = max(page_width * 0.05, (x1 - x0) * 0.15)
    if abs(center - page_width / 2.0) < tolerance and abs(left_gap - right_gap) < tolerance:
        return WD_ALIGN_PARAGRAPH.CENTER
    if right_gap < page_width * 0.06 and left_gap > page_width * 0.10:
        return WD_ALIGN_PARAGRAPH.RIGHT
    if left_gap < page_width * 0.02:
        return WD_ALIGN_PARAGRAPH.JUSTIFY
    return WD_ALIGN_PARAGRAPH.LEFT


def pdf_to_docx(pdf_path: str, output_docx_path: str, log=None) -> str:
    """将 PDF 转换为 .docx。

    - 文本块按位置排序重建为段落；
    - 图片以真实图片形式插入到对应位置；
    - 输出文件路径与输入同名（扩展名 .docx），除非显式给出 output_docx_path。
    """
    def _log(msg):
        if log is not None:
            try:
                log(msg)
            except Exception:
                pass

    pdf_path = os.fspath(pdf_path)
    output_docx_path = os.fspath(output_docx_path)
    if not os.path.exists(pdf_path):
        raise FileNotFoundError(f"PDF 文件不存在: {pdf_path}")

    _log(f"[PDF→Word] 正在解析 PDF: {os.path.basename(pdf_path)}")
    doc = Document()

    fitz_doc = fitz.open(pdf_path)
    try:
        total_pages = fitz_doc.page_count
        for page_index in range(total_pages):
            page = fitz_doc.load_page(page_index)
            page_width = page.rect.width
            page_height = page.rect.height
            _log(f"  > 处理第 {page_index + 1}/{total_pages} 页")

            blocks = []
            raw = page.get_text("dict")
            for block in raw.get("blocks", []):
                blocks.append(block)

            # 文本块与图片块统一按 (y0, x0) 排序，保持阅读顺序
            blocks.sort(key=lambda b: (b.get("bbox", (0, 0, 0, 0))[1], b.get("bbox", (0, 0, 0, 0))[0]))

            for block in blocks:
                bbox = block.get("bbox", (0, 0, 0, 0))
                btype = block.get("type", -1)

                if btype == 0:  # 文本块
                    lines = block.get("lines", [])
                    if not lines:
                        continue
                    # 拼接行内 spans 文本，统计字号与加粗
                    lines_text = []
                    block_size = None
                    block_bold = False
                    for line in lines:
                        line_text = ""
                        line_size = None
                        line_bold = False
                        for span in line.get("spans", []):
                            line_text += span.get("text", "")
                            sz = span.get("size")
                            if sz and sz > 0:
                                line_size = sz
                            if span.get("flags", 0) & 16:  # bold bit
                                line_bold = True
                        if line_size and (block_size is None or line_size > block_size):
                            block_size = line_size
                        if line_bold:
                            block_bold = True
                        lines_text.append(line_text.rstrip())

                    full_text = "\n".join(lines_text).strip()
                    if not full_text:
                        continue

                    para = doc.add_paragraph()
                    para.alignment = _extract_block_alignment(block, page_width)

                    size_pt = _nearest_common_size(block_size) if block_size else 16.0
                    run = para.add_run(full_text)
                    run.font.size = Pt(size_pt)
                    run.bold = block_bold

                elif btype == 1:  # 图片块
                    image_bytes = block.get("image")
                    if not image_bytes:
                        xref = block.get("number")
                        if xref:
                            try:
                                image_info = page.parent.extract_image(xref)
                                image_bytes = image_info.get("image")
                            except Exception:
                                image_bytes = None
                    if not image_bytes:
                        continue

                    # 计算图片在 Word 中的显示宽度（按源 PDF 页面宽度比例换算到内容区）
                    try:
                        content_width_cm = 21.0 - 2.8 - 2.6  # 参考默认左右边距
                        page_cm_width = page_width / 28.3465
                        ratio = (bbox[2] - bbox[0]) / page_width if page_width else 0.9
                        ratio = max(0.1, min(1.0, ratio))
                        img_width_cm = round(page_cm_width * ratio, 2)
                        if img_width_cm > content_width_cm:
                            img_width_cm = content_width_cm
                    except Exception:
                        img_width_cm = 14.0

                    img_para = doc.add_paragraph()
                    img_para.alignment = _extract_block_alignment(block, page_width)
                    run_img = img_para.add_run()
                    try:
                        stream = io.BytesIO(image_bytes)
                        run_img.add_picture(stream, width=Cm(max(1.0, img_width_cm)))
                    except Exception:
                        _log(f"  > 第 {page_index + 1} 页图片插入失败（已跳过图片）")
                        continue
                    _log(f"  > 第 {page_index + 1} 页插入图片（{len(image_bytes)} 字节）, 宽 {img_width_cm}cm")

            if page_index < total_pages - 1:
                # 不同页之间留一个空行分隔
                doc.add_paragraph()
    finally:
        fitz_doc.close()

    out_path = os.fspath(output_docx_path)
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    doc.save(out_path)
    _log(f"[PDF→Word] 转换完成: {out_path}")
    return out_path


def extract_pdf_layout(pdf_path: str, log=None) -> dict:
    """从 PDF 提取排版参数（尽力而为）。

    基于文本块坐标统计推断：
    - 页面尺寸 / 页边距（文本内容边界）
    - 正文字号 / 标题字号（按出现频率与字号聚类）
    - 对齐方式分布（用于判断页码对齐等）

    注意：PDF 不携带语义化的样式结构，提取结果仅供参考，
    准确度低于 .docx 模板导入。无文本层的扫描版 PDF 无法提取。
    """
    def _log(msg):
        if log is not None:
            try:
                log(msg)
            except Exception:
                pass

    pdf_path = os.fspath(pdf_path)
    if not os.path.exists(pdf_path):
        raise FileNotFoundError(f"PDF 文件不存在: {pdf_path}")

    layout = {}
    fitz_doc = fitz.open(pdf_path)
    try:
        if fitz_doc.page_count == 0:
            raise ValueError("PDF 没有任何页面。")

        first_page = fitz_doc.load_page(0)
        page_width = first_page.rect.width
        page_height = first_page.rect.height
        # A4: 595.276 x 841.89 pt
        layout["is_a4"] = abs(page_width - 595.276) < 20 and abs(page_height - 841.89) < 20
        layout["page_width_cm"] = round(page_width / 28.3465, 2)
        layout["page_height_cm"] = round(page_height / 28.3465, 2)

        margin_top = margin_bottom = margin_left = margin_right = None
        sizes = []
        total_blocks = 0
        centered_blocks = 0
        left_blocks = 0
        right_blocks = 0

        for page_index in range(min(fitz_doc.page_count, 5)):
            page = fitz_doc.load_page(page_index)
            pw = page.rect.width
            ph = page.rect.height
            raw = page.get_text("dict")
            page_blocks = raw.get("blocks", [])
            text_blocks = [b for b in page_blocks if b.get("type") == 0]
            if not text_blocks:
                continue
            total_blocks += len(text_blocks)

            for block in text_blocks:
                bbox = block.get("bbox", (0, 0, pw, ph))
                x0, y0, x1, y1 = bbox
                margin_top = y0 if margin_top is None else min(margin_top, y0)
                margin_left = x0 if margin_left is None else min(margin_left, x0)
                margin_bottom = (ph - y1) if margin_bottom is None else max(margin_bottom, ph - y1)
                margin_right = (pw - x1) if margin_right is None else max(margin_right, pw - x1)

                align = _extract_block_alignment(block, pw)
                if align == WD_ALIGN_PARAGRAPH.CENTER:
                    centered_blocks += 1
                elif align == WD_ALIGN_PARAGRAPH.RIGHT:
                    right_blocks += 1
                else:
                    left_blocks += 1

                for line in block.get("lines", []):
                    for span in line.get("spans", []):
                        sz = span.get("size")
                        if sz and sz > 0:
                            sizes.append(sz)

        if total_blocks == 0:
            raise ValueError("该 PDF 没有可提取的文本层（可能是扫描件），无法导入排版参数。")

        # 页边距（转换为 cm，与排版工具单位一致）
        if margin_top is not None:
            layout["margin_top"] = round(max(0.0, _points_to_cm(margin_top)), 2)
        if margin_bottom is not None:
            layout["margin_bottom"] = round(max(0.0, _points_to_cm(margin_bottom)), 2)
        if margin_left is not None:
            layout["margin_left"] = round(max(0.0, _points_to_cm(margin_left)), 2)
        if margin_right is not None:
            layout["margin_right"] = round(max(0.0, _points_to_cm(margin_right)), 2)

        # 字号统计：正文 = 出现频率最高；标题 = 明显更大的簇
        if sizes:
            from collections import Counter
            common = Counter(sizes)
            most_common_size, freq = common.most_common(1)[0]
            layout["body_size"] = _nearest_common_size(most_common_size)
            layout["body_size_confidence"] = freq / len(sizes)

            # 找大于正文字号一个档位的字号簇
            larger = [s for s in common.elements() if s > layout["body_size"] + 1.5]
            if larger:
                title_size = max(set(larger), key=larger.count)
                layout["title_size"] = _nearest_common_size(title_size)
            else:
                layout["title_size"] = None

        # 对齐分布
        layout["page_number_align"] = "奇偶分页"  # 默认
        if centered_blocks == total_blocks and total_blocks > 1:
            layout["page_number_align"] = "居中"

        _log(f"[PDF→布局] 提取完成：正文 {layout.get('body_size')}pt, "
             f"标题 {layout.get('title_size')}pt, "
             f"边距 T{layout.get('margin_top')} B{layout.get('margin_bottom')} "
             f"L{layout.get('margin_left')} R{layout.get('margin_right')}")
    finally:
        fitz_doc.close()

    return layout


def pdf_layout_usable(layout: dict) -> bool:
    """判断提取结果是否可信到可以作为配置导入。

    扫描版/文本层缺失的 PDF 会缺少 body_size 或 margin 信息，判定为不可用。
    """
    if not layout:
        return False
    if layout.get("body_size") is None:
        return False
    if any(layout.get(k) is None for k in ("margin_top", "margin_bottom", "margin_left", "margin_right")):
        return False
    return True


def merge_pdf_layout_into_config(layout: dict, base_config: dict) -> dict:
    """将 PDF 提取结果合并进完整排版配置。"""
    merged = dict(base_config)
    if not layout:
        return merged
    for key in ("margin_top", "margin_bottom", "margin_left", "margin_right", "footer_distance"):
        if layout.get(key) is not None:
            merged[key] = layout[key]
    if layout.get("is_a4") is True:
        merged["force_a4"] = True
    if layout.get("title_size"):
        merged["title_size"] = layout["title_size"]
    if layout.get("body_size"):
        merged["body_size"] = layout["body_size"]
    if layout.get("page_number_align"):
        merged["page_number_align"] = layout["page_number_align"]
    return merged
