# -*- coding: utf-8 -*-
"""模板排版参数提取与确认面板。

- extract_docx_layout: 从 .docx 模板文档提取排版参数（页面/标题/正文等）
- extract_pdf_layout:  从 PDF 提取排版参数（尽力而为，见 wfp_pdf_tools）
- TemplateConfirmDialog: 通用确认面板，展示提取到的参数并允许用户修改，
  确认后可保存为自定义配置 JSON 供一键排版使用。
"""

from __future__ import annotations

import json
import os
import re

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Length


RE_H1 = re.compile(r"^[一二三四五六七八九十]{1,3}、")
RE_H2 = re.compile(r"^[（(][一二三四五六七八九十]{1,3}[)）]")
RE_H3 = re.compile(r"^\d{1,2}\.")
RE_H4 = re.compile(r"^[（(]\d{1,2}[)）]")
RE_ATTACH = re.compile(r"^附件[:：]?\s*\d*")


# 参数元信息：key -> (中文标签, 类型, 选项)
# 类型: 'float' | 'int' | 'str' | 'choice' | 'bool'
CONFIG_PARAM_META = {
    # 页面设置
    "margin_top": ("上边距 (cm)", "float", None),
    "margin_bottom": ("下边距 (cm)", "float", None),
    "margin_left": ("左边距 (cm)", "float", None),
    "margin_right": ("右边距 (cm)", "float", None),
    "footer_distance": ("页脚距 (cm)", "float", None),
    "force_a4": ("强制 A4 纸张", "bool", None),
    "page_number_align": ("页码对齐", "choice", ["奇偶分页", "居中"]),
    # 主标题
    "title_font": ("题目字体", "str", None),
    "title_size": ("题目字号 (pt)", "float", None),
    "title_line_spacing": ("题目行距", "float", None),
    "title_bold": ("题目加粗", "bool", None),
    # 副标题
    "subtitle_font": ("副标题字体", "str", None),
    "subtitle_size": ("副标题字号 (pt)", "float", None),
    "subtitle_line_spacing": ("副标题行距", "float", None),
    # 一级标题
    "h1_font": ("一级标题字体", "str", None),
    "h1_size": ("一级标题字号 (pt)", "float", None),
    "h1_bold": ("一级标题加粗", "bool", None),
    # 二级标题
    "h2_font": ("二级标题字体", "str", None),
    "h2_size": ("二级标题字号 (pt)", "float", None),
    "h2_bold": ("二级标题加粗", "bool", None),
    # 正文
    "body_font": ("正文/三四级字体", "str", None),
    "body_size": ("正文/三四级字号 (pt)", "float", None),
    "line_spacing": ("正文行距", "float", None),
    "first_line_indent_chars": ("首行缩进 (字符)", "float", None),
    "left_indent_cm": ("左缩进 (cm)", "float", None),
    "right_indent_cm": ("右缩进 (cm)", "float", None),
}


def _emu_to_cm(value) -> float:
    if value is None:
        return None
    try:
        if isinstance(value, Length):
            return round(value.cm, 2)
        return round(float(value) / 360000.0, 2)
    except (TypeError, ValueError):
        return None


def _run_east_asia_font(run):
    try:
        r_fonts = run._r.rPr.rFonts if run._r.rPr is not None else None
        if r_fonts is None:
            r_fonts = run._r.find(qn("w:rPr") + "/" + qn("w:rFonts"))
        if r_fonts is None:
            return None
        ea = r_fonts.get(qn("w:eastAsia"))
        return ea or run.font.name
    except Exception:
        return run.font.name


def _para_font_info(para):
    """返回 (中文字体, 西文字体, 字号pt, 加粗)。取第一个非空 run。"""
    for run in para.runs:
        if run.text.strip():
            size = run.font.size.pt if run.font.size else None
            bold = run.font.bold
            ea = _run_east_asia_font(run)
            return ea, run.font.name, size, bold
    return None, None, None, None


def _para_line_spacing_pt(para):
    fmt = para.paragraph_format
    ls = fmt.line_spacing
    if ls is None:
        return None
    try:
        if isinstance(ls, Length):
            return round(ls.pt, 1)
        return round(ls, 2)
    except Exception:
        return None


def _para_first_line_indent_chars(para):
    """读取首行缩进。优先 w:firstLineChars（字符），否则按磅换算字符。"""
    try:
        p_pr = para._p.pPr
        if p_pr is not None:
            ind = p_pr.find(qn("w:ind"))
            if ind is not None:
                chars = ind.get(qn("w:firstLineChars"))
                if chars is not None:
                    try:
                        return round(int(chars) / 100.0, 2)
                    except (TypeError, ValueError):
                        pass
        fmt = para.paragraph_format
        if fmt.first_line_indent is not None:
            return round(float(fmt.first_line_indent) / 360000.0 * 56.69, 2)
    except Exception:
        pass
    return None


def _page_number_alignment(doc):
    """从页脚/页眉推断页码对齐方式。"""
    try:
        for section in doc.sections:
            footer = section.footer
            if footer is None:
                continue
            for para in footer.paragraphs:
                if para.text.strip():
                    if para.alignment == WD_ALIGN_PARAGRAPH.CENTER:
                        return "居中"
        # 偶数页页脚
        for section in doc.sections:
            even_footer = getattr(section, "even_page_footer", None)
            if even_footer is None:
                continue
            for para in even_footer.paragraphs:
                if para.text.strip() and para.alignment == WD_ALIGN_PARAGRAPH.CENTER:
                    return "居中"
    except Exception:
        pass
    return "奇偶分页"


def extract_docx_layout(docx_path: str, log=None) -> dict:
    """从 .docx 模板文档提取排版参数，返回可直接合并进配置的 dict。

    提取策略：
    - 页面设置：取第一个 section 的页边距、页脚距、纸张尺寸
    - 主标题：文档开头第一个非空、居中的大字号段落
    - 副标题：主标题之后第一个居中的段落
    - 一级标题：以"一、"等开头的段落（取首次出现）
    - 二级标题：以"（一）"等开头的段落（取首次出现）
    - 正文：第一个普通左对齐段落
    """
    def _log(msg):
        if log is not None:
            try:
                log(msg)
            except Exception:
                pass

    if not os.path.exists(docx_path):
        raise FileNotFoundError(f"模板文档不存在: {docx_path}")

    _log(f"[模板导入] 正在解析模板文档: {os.path.basename(docx_path)}")
    doc = Document(docx_path)
    layout = {}

    # ---- 页面设置 ----
    try:
        section = doc.sections[0]
        layout["margin_top"] = _emu_to_cm(section.top_margin)
        layout["margin_bottom"] = _emu_to_cm(section.bottom_margin)
        layout["margin_left"] = _emu_to_cm(section.left_margin)
        layout["margin_right"] = _emu_to_cm(section.right_margin)
        layout["footer_distance"] = _emu_to_cm(section.footer_distance)
        pw = section.page_width
        ph = section.page_height
        if pw is not None and ph is not None:
            w_cm, h_cm = pw.cm, ph.cm
            layout["force_a4"] = abs(w_cm - 21.0) < 1.5 and abs(h_cm - 29.7) < 1.5
        layout["page_number_align"] = _page_number_alignment(doc)
    except Exception as e:
        _log(f"  > 页面设置提取失败: {e}")

    # ---- 遍历段落识别标题与正文 ----
    found = {"title": False, "subtitle": False, "h1": False, "h2": False, "body": False}
    prev_centered_big = False  # 上一个居中段落是否被当作主标题

    for para in doc.paragraphs:
        text = para.text.strip()
        if not text:
            continue
        ea_font, en_font, size_pt, bold = _para_font_info(para)
        align = para.alignment
        is_centered = align == WD_ALIGN_PARAGRAPH.CENTER
        ls_pt = _para_line_spacing_pt(para)

        if RE_ATTACH.match(text) and not found["title"]:
            continue

        # 层级标题（按优先级）
        if not found["title"] and is_centered and size_pt and size_pt >= 18:
            # 主标题
            layout["title_font"] = ea_font or en_font
            layout["title_size"] = size_pt
            if ls_pt:
                layout["title_line_spacing"] = ls_pt
            layout["title_bold"] = bool(bold)
            found["title"] = True
            prev_centered_big = True
            continue
        if found["title"] and not found["subtitle"] and is_centered and size_pt and size_pt < 18:
            layout["subtitle_font"] = ea_font or en_font
            layout["subtitle_size"] = size_pt
            if ls_pt:
                layout["subtitle_line_spacing"] = ls_pt
            found["subtitle"] = True
            prev_centered_big = False
            continue

        if not found["h1"] and RE_H1.match(text):
            layout["h1_font"] = ea_font or en_font
            layout["h1_size"] = size_pt or 16
            layout["h1_bold"] = bool(bold)
            found["h1"] = True
            prev_centered_big = False
            continue
        if not found["h2"] and RE_H2.match(text):
            layout["h2_font"] = ea_font or en_font
            layout["h2_size"] = size_pt or 16
            layout["h2_bold"] = bool(bold)
            found["h2"] = True
            prev_centered_big = False
            continue

        # 正文：第一个非标题、非空、未识别为居中的段落
        if not found["body"] and not is_centered and not RE_H1.match(text) and not RE_H2.match(text):
            layout["body_font"] = ea_font or en_font
            layout["body_size"] = size_pt or 16
            if ls_pt:
                layout["line_spacing"] = ls_pt
            fli = _para_first_line_indent_chars(para)
            if fli is not None:
                layout["first_line_indent_chars"] = fli
            layout["left_indent_cm"] = _emu_to_cm(para.paragraph_format.left_indent)
            layout["right_indent_cm"] = _emu_to_cm(para.paragraph_format.right_indent)
            found["body"] = True

    _log(f"[模板导入] 提取完成：标题 {layout.get('title_font')} {layout.get('title_size')}pt, "
         f"正文 {layout.get('body_font')} {layout.get('body_size')}pt")
    return layout


def merge_layout_into_config(layout: dict, base_config: dict) -> dict:
    """将提取到的参数合并进完整配置。"""
    merged = dict(base_config)
    if not layout:
        return merged
    for key, value in layout.items():
        if key in merged and value is not None:
            merged[key] = value
    return merged


def render_param_rows(layout: dict):
    """将提取结果转成确认面板行数据：[(key, label, type, value)]。"""
    rows = []
    for key, (label, ptype, options) in CONFIG_PARAM_META.items():
        if key not in layout or layout[key] is None:
            continue
        rows.append((key, label, ptype, options, layout[key]))
    return rows


def save_custom_config(config: dict, file_path: str) -> None:
    """将配置保存为 JSON 文件。"""
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=4)


# --------------------------------------------------------------------------
# Tkinter 确认面板（懒加载，避免无 GUI 环境下 import 失败）
# --------------------------------------------------------------------------
def open_template_confirm_dialog(master, rows, config, title, on_confirm, on_cancel=None, warning=""):
    """打开确认面板。

    rows: [(key, label, type, options, value)] 由 render_param_rows 生成
    config: 完整配置 dict（确认后回填）
    on_confirm(modified_config): 用户点击"确认"后的回调
    on_cancel(): 取消回调（可为 None）
    warning: 顶部警告说明（如 PDF 提取准确度说明）
    """
    import tkinter as tk
    from tkinter import ttk, messagebox

    win = tk.Toplevel(master)
    win.title(title)
    win.geometry("560x620")
    win.transient(master)
    win.grab_set()

    container = ttk.Frame(win)
    container.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)

    if warning:
        warn_label = ttk.Label(
            container, text=warning, foreground="#b45309", wraplength=520, justify=tk.LEFT
        )
        warn_label.pack(fill=tk.X, pady=(0, 6))

    # 滚动区
    canvas = tk.Canvas(container, highlightthickness=0)
    scrollbar = ttk.Scrollbar(container, orient=tk.VERTICAL, command=canvas.yview)
    inner = ttk.Frame(canvas)
    inner_id = canvas.create_window((0, 0), window=inner, anchor="nw")

    def _on_configure(_e=None):
        canvas.configure(scrollregion=canvas.bbox("all"))

    def _fit_width(event):
        canvas.itemconfig(inner_id, width=event.width)

    inner.bind("<Configure>", _on_configure)
    canvas.bind("<Configure>", _fit_width)
    canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    canvas.configure(yscrollcommand=scrollbar.set)

    var_map = {}
    r = 0
    ttk.Label(inner, text="排版参数（可直接修改）", font=("Helvetica", 10, "bold")).grid(
        row=r, column=0, columnspan=3, sticky="w", pady=(0, 6)
    )
    r += 1
    for key, label, ptype, options, value in rows:
        ttk.Label(inner, text=label).grid(row=r, column=0, sticky="w", padx=4, pady=2)
        if ptype == "choice":
            var = tk.StringVar(value=str(value))
            combo = ttk.Combobox(inner, values=options, textvariable=var, state="readonly", width=28)
            combo.grid(row=r, column=1, columnspan=2, sticky="ew", padx=4, pady=2)
        elif ptype == "bool":
            var = tk.BooleanVar(value=bool(value))
            ttk.Checkbutton(inner, variable=var).grid(row=r, column=1, sticky="w", padx=4, pady=2)
        else:
            var = tk.StringVar(value="" if value is None else str(value))
            entry = ttk.Entry(inner, textvariable=var, width=28)
            entry.grid(row=r, column=1, columnspan=2, sticky="ew", padx=4, pady=2)
        var_map[key] = (ptype, var)
        r += 1

    result = {}

    def _collect():
        try:
            for key, (ptype, var) in var_map.items():
                raw = var.get()
                if ptype == "bool":
                    result[key] = bool(var.get())
                elif ptype == "float":
                    result[key] = float(raw) if str(raw).strip() else None
                elif ptype == "int":
                    result[key] = int(raw) if str(raw).strip() else None
                else:
                    result[key] = str(raw).strip()
            merged = merge_layout_into_config(result, config)
            win.destroy()
            on_confirm(merged)
        except (ValueError, TypeError) as e:
            messagebox.showerror("参数错误", f"请输入有效数值。\n{e}", parent=win)

    btn_frame = ttk.Frame(win)
    btn_frame.pack(fill=tk.X, padx=8, pady=8)
    ttk.Button(btn_frame, text="确认", command=_collect).pack(side=tk.RIGHT, padx=4)
    ttk.Button(btn_frame, text="取消", command=lambda: (win.destroy(), on_cancel() if on_cancel else None)).pack(
        side=tk.RIGHT, padx=4
    )
    return win
